<section class="move-area z-0 ">
  <div class=".container absolute"
	style="top: 40%;
	right: 70%;">
    <div class='eyeD'></div>
  </div>
  <div class=".container absolute"
	style="top: 40%;
	right: 17%;">
    <div class='eyeI'></div>
  </div>
</section>