<div class="w-fit inline">
	<x-flecha_izquierda id="valor1" min="1"/>
	<div class="inline text-4xl" id="valor1">05</div>
	<x-flecha_derecha id="valor1" max="15"/>
</div>
