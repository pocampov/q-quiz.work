<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Jugar extends Component
{
    public function render()
    {
        return view('livewire.jugar'); 
    }
}
