<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Vacio extends Component
{
	public function mount(...$parameters)
	{
		
	}
    public function render()
    {
        return view('livewire.vacio');
    }
}
