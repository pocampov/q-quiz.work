<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PublicaParticipanteController extends Controller
{
    //
}
