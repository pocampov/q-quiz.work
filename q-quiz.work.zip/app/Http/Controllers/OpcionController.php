<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OpcionController extends Controller
{
    //
}
