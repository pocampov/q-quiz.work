<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RespuestaController extends Controller
{
    //
}
